package utils;

public enum PhotoType {
    HORIZONTAL,
    VERTICAL
}
